Ext.define('NewsHolder.view.SearchPanel', {
    extend: 'Ext.Panel',

    config: {
        id: 'searchMain',
        layout: {
            type: 'card'
        },
        items: [
            {
                xtype: 'titlebar',
                docked: 'top',
                id: 'searchTitleBar',
                title: '키워드 검색'
            },
            {
                xtype: 'panel',
                layout: {
                    type: 'vbox'
                },
                items: [
                    {
                        xtype: 'panel',
                        layout: {
                            type: 'hbox'
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                flex: 1,
                                id: 'searchField'
                            },
                            {
                                xtype: 'button',
                                id: 'searchButton',
                                ui: 'action',
                                iconCls: 'search',
                                iconMask: true
                            }
                        ]
                    },
                    {
                        xtype: 'list',
                        flex: 1,
                        id: 'searchList',
                        itemTpl: [
                            '<div>{xindex}. {keyword}</div>'
                        ],
                        store: 'ranksStore'
                    }
                ]
            },
            {
                xtype: 'panel',
                layout: {
                    type: 'vbox'
                },
                items: [
                    {
                        xtype: 'panel',
                        id: 'selectedArticle',
                        styleHtmlContent: true,
                        tpl: [
                            '{description}'
                        ],
                        layout: {
                            type: 'fit'
                        }
                    }
                ]
            }
        ]
    }

});